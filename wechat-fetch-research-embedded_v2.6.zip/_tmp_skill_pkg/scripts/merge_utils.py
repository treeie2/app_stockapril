"""
共享合并工具模块 (v2.5)
提取 6 个脚本中重复的文章合并/分片读写逻辑，统一为公共函数。
所有脚本直接 import 此模块，不再各自实现去重逻辑。

使用示例:
    from merge_utils import merge_articles, load_master, save_master
    master = load_master(PROJECT_ROOT)
    for code, new_stock in new_stocks.items():
        existing = master['stocks'].setdefault(code, new_stock)
        existing['articles'] = merge_articles(existing.get('articles', []), new_stock.get('articles', []))
        merge_set_fields(existing, new_stock)
    save_master(PROJECT_ROOT, master)
"""

import json
from datetime import date
from pathlib import Path
from typing import Dict, Any, List, Optional

SET_FIELDS = ['concepts', 'products', 'core_business', 'industry_position', 'chain', 'partners']


def merge_articles(existing: List[Dict], new_articles: List[Dict]) -> List[Dict]:
    """
    按 (title, source) 去重合并文章列表。返回合并后的列表。
    """
    if not new_articles:
        return existing
    existing_keys = {(a.get('title', ''), a.get('source', '')) for a in existing}
    for a in new_articles:
        key = (a.get('title', ''), a.get('source', ''))
        if key not in existing_keys:
            existing.append(a)
            existing_keys.add(key)
    return existing


def merge_set_fields(existing: Dict, new_stock: Dict) -> None:
    """
    合并 set 字段（concepts, products, core_business, industry_position, chain, partners）。
    直接在 existing 字典上修改。
    """
    for field in SET_FIELDS:
        if new_stock.get(field):
            existing_set = set(existing.get(field) or [])
            if isinstance(new_stock[field], str):
                existing_set.add(new_stock[field])
            else:
                existing_set.update(new_stock[field])
            existing[field] = sorted(existing_set)


def load_master(project_root: Path) -> Dict:
    """加载主数据文件 data/stocks/stocks_master.json"""
    path = project_root / 'data' / 'stocks' / 'stocks_master.json'
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_master(project_root: Path, master: Dict) -> Path:
    """保存主数据文件。返回文件路径。"""
    path = project_root / 'data' / 'stocks' / 'stocks_master.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(master, f, ensure_ascii=False, indent=2)
    return path


def load_or_create_shard(project_root: Path, date_str: str) -> Dict:
    """加载或创建日期分片文件 data/stocks/YYYY-MM-DD.json"""
    path = project_root / 'data' / 'stocks' / f'{date_str}.json'
    if path.exists():
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {'date': date_str, 'update_count': 0, 'stocks': {}}


def save_shard(project_root: Path, date_str: str, shard: Dict) -> Path:
    """保存日期分片文件。返回文件路径。"""
    path = project_root / 'data' / 'stocks' / f'{date_str}.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(shard, f, ensure_ascii=False, indent=2)
    return path


def is_duplicate_article(articles: List[Dict], new_article: Dict) -> bool:
    """检查新文章是否已在列表中存在（按 source 去重）"""
    new_source = new_article.get('source', '')
    return any(a.get('source', '') == new_source for a in articles) if new_source else False
