"""Update an existing stock group by directly writing to groups.json."""
import sys
import json
from _common import load_groups, save_groups, today_str

def main():
    if len(sys.argv) < 3:
        print("用法: python update_group.py <group_id> [--name 新名称] [--description 新描述] [--stocks 个股(逗号分隔)] [--color 颜色] [--icon 图标]")
        print("示例: python update_group.py group_20260511000000 --name \"新名称\" --description \"新描述\"")
        sys.exit(1)

    group_id = sys.argv[1]
    updates = {}
    i = 2
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg == "--name" and i + 1 < len(sys.argv):
            updates["name"] = sys.argv[i + 1]; i += 2
        elif arg == "--description" and i + 1 < len(sys.argv):
            updates["description"] = sys.argv[i + 1]; i += 2
        elif arg == "--stocks" and i + 1 < len(sys.argv):
            updates["stocks"] = [s.strip() for s in sys.argv[i + 1].split(",") if s.strip()]; i += 2
        elif arg == "--color" and i + 1 < len(sys.argv):
            updates["color"] = sys.argv[i + 1]; i += 2
        elif arg == "--icon" and i + 1 < len(sys.argv):
            updates["icon"] = sys.argv[i + 1]; i += 2
        else:
            print(f"[WARN] 忽略未知参数: {arg}")
            i += 1

    if not updates:
        print("[ERR] 未提供任何要更新的字段")
        sys.exit(1)

    data = load_groups()
    found = False
    for g in data["groups"]:
        if g["id"] == group_id:
            g.update(updates)
            g["updated_at"] = today_str()
            found = True
            break

    if not found:
        print(f"[ERR] 未找到分组 ID: {group_id}")
        sys.exit(1)

    save_groups(data)
    print(f"[OK] 分组已更新: {g['name']} ({group_id})")
    print(f"  更新字段: {', '.join(updates.keys())}")
    print(f"  (已同步到 agent_store)")

if __name__ == "__main__":
    main()
