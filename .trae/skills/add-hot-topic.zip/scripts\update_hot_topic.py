"""Update an existing hot topic by directly writing to hot_topics.json."""
import sys
import json
from _common import load_topics, save_topics, today_str

def main():
    if len(sys.argv) < 3:
        print("用法: python update_hot_topic.py <topic_id> [--name 新名称] [--drivers 新驱动] [--stocks 个股(逗号分隔)]")
        print("示例: python update_hot_topic.py topic_20260506000000 --name \"新名称\" --drivers \"新驱动因素\"")
        sys.exit(1)

    topic_id = sys.argv[1]
    updates = {}
    i = 2
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg == "--name" and i + 1 < len(sys.argv):
            updates["name"] = sys.argv[i + 1]; i += 2
        elif arg == "--drivers" and i + 1 < len(sys.argv):
            updates["drivers"] = sys.argv[i + 1]; i += 2
        elif arg == "--stocks" and i + 1 < len(sys.argv):
            updates["stocks"] = [s.strip() for s in sys.argv[i + 1].split(",") if s.strip()]
            i += 2
        else:
            print(f"[WARN] 忽略未知参数: {arg}")
            i += 1

    if not updates:
        print("[ERR] 未提供任何要更新的字段")
        sys.exit(1)

    data = load_topics()
    found = False
    for t in data["topics"]:
        if t["id"] == topic_id:
            t.update(updates)
            t["updated_at"] = today_str()
            found = True
            break

    if not found:
        print(f"[ERR] 未找到热点 ID: {topic_id}")
        sys.exit(1)

    save_topics(data)
    print(f"[OK] 热点已更新: {t['name']} ({topic_id})")
    print(f"  更新字段: {', '.join(updates.keys())}")
    print(f"  (已同步到 agent_store)")

if __name__ == "__main__":
    main()
